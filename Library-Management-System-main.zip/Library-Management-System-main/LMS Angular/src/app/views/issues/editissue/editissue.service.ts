// import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// @Injectable({
//   providedIn: 'root',
// })
// export class EditissueService {
//   private Url = '/api/';
//   private apiurl = this.Url + 'issuebooks/';
//   constructor(private _http: HttpClient) {}
//   getIssue(id: any) {
//     return this._http.get(this.apiurl + id);
//   }

//   editIssue(id: any, body: any) {
//     return this._http.put(this.apiurl + id, body);
//   }
// }
