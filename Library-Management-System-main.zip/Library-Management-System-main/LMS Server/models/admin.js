const mongoose = require("mongoose");

const adminSchema = mongoose.Schema(
  {
    first_name: {
      type: String,
      required: true,
    },
    last_name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
      trim: true,
      lowercase: true,
      match: [
        /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
        "Please fill a valid email address",
      ],
    },
    password: {
      type: String,
      required: true,
    },
    phone_no: {
      type: String,
      required: true,
      min: 10,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Admins", adminSchema);
